package com.example.opensource_num2

data class UserData(
    val id:String? = null,
    val username:String? = null,
    val password:String? = null
)
data class CollectionItem(val title: String, val description: String, val imageResId: Int)

