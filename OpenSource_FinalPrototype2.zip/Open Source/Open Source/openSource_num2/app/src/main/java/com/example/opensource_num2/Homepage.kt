package com.example.opensource_num2

import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity3 : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.homepage)

        val recyclerView: RecyclerView = findViewById(R.id.recyclerView)
        recyclerView.layoutManager = GridLayoutManager(this, 2)

        val items = generateFakeItems()

        val btnAddCategory = findViewById<Button>(R.id.btnAddCategory)
                val btnCreateCollection = findViewById<Button>(R.id.btnCreateCollection)

                // Set click listeners for the buttons
                btnAddCategory.setOnClickListener {
            // Handle Add Category button click
            // Add your logic here
        }

        btnCreateCollection.setOnClickListener {
            // Handle Create New Collection button click
            // Add your logic here
        }
    }

    private fun generateFakeItems(): List<CollectionItem> {
        val items = ArrayList<CollectionItem>()
        items.add(CollectionItem("Category 1", "Description 1", R.drawable.image1))
        items.add(CollectionItem("Category 2", "Description 2", R.drawable.image2))
        items.add(CollectionItem("Category 3", "Description 3", R.drawable.image3))
        items.add(CollectionItem("Category 4", "Description 4", R.drawable.image4))
        // Add more fake items as needed
        return items
    }
}

